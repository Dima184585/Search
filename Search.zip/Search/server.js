const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();

const PORT = 3000;
const HOST = "0.0.0.0";

// ============================================================
// ТОЛЬКО ЭТА ПАПКА
// ============================================================

const ROOT = __dirname;

// ============================================================
// ТОЛЬКО ЭТОТ HTML
// ============================================================

const HTML_FILE =
    path.join(ROOT, "search.html");

// ============================================================
// DATA
// ============================================================

const DATA_DIR =
    path.join(ROOT, "data");

const USERS_FILE =
    path.join(DATA_DIR, "users.json");

// ============================================================
// API KEYS
// ============================================================

const YANDEX_API_KEY =
    process.env.YANDEX_API_KEY || "";

const YANDEX_FOLDER_ID =
    process.env.YANDEX_FOLDER_ID || "";

const GOOGLE_API_KEY =
    process.env.GOOGLE_API_KEY || "";

const GOOGLE_CX =
    process.env.GOOGLE_CX || "";

// ============================================================
// EXPRESS
// ============================================================

app.use(
    express.json({
        limit: "2mb"
    })
);

app.use(
    express.urlencoded({
        extended: true
    })
);

// ============================================================
// ПРОВЕРКА ПАПКИ
// ============================================================

if (!fs.existsSync(ROOT)) {
    console.error("");
    console.error(
        "ОШИБКА: ПАПКА SEARCH НЕ НАЙДЕНА!"
    );
    console.error("");
    console.error(ROOT);
    console.error("");
    process.exit(1);
}

// ============================================================
// ПРОВЕРКА SEARCH.HTML
// ============================================================

if (!fs.existsSync(HTML_FILE)) {
    console.error("");
    console.error(
        "ОШИБКА: search.html НЕ НАЙДЕН!"
    );
    console.error("");
    console.error(
        "Ожидаемый путь:"
    );
    console.error("");
    console.error(
        HTML_FILE
    );
    console.error("");

    process.exit(1);
}

// ============================================================
// DATA
// ============================================================

if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(
        DATA_DIR,
        {
            recursive: true
        }
    );
}

if (!fs.existsSync(USERS_FILE)) {
    fs.writeFileSync(
        USERS_FILE,
        "[]",
        "utf8"
    );
}

// ============================================================
// USERS
// ============================================================

function loadUsers() {
    try {
        const data =
            fs.readFileSync(
                USERS_FILE,
                "utf8"
            );

        if (!data.trim()) {
            return [];
        }

        const users =
            JSON.parse(data);

        return Array.isArray(users)
            ? users
            : [];

    } catch (error) {

        console.error(
            "Ошибка чтения users.json:",
            error
        );

        return [];
    }
}

function saveUsers(users) {

    fs.writeFileSync(
        USERS_FILE,
        JSON.stringify(
            users,
            null,
            2
        ),
        "utf8"
    );
}

// ============================================================
// ГЛАВНАЯ СТРАНИЦА
// ============================================================

app.get(
    "/",
    (req, res) => {

        console.log(
            "Открыта Search:"
        );

        console.log(
            HTML_FILE
        );

        res.sendFile(
            HTML_FILE
        );
    }
);

// ============================================================
// SEARCH.HTML
// ============================================================

app.get(
    "/search.html",
    (req, res) => {

        res.sendFile(
            HTML_FILE
        );
    }
);

// ============================================================
// STATIC
// ============================================================
//
// Разрешаем CSS/JS/картинки из ТОЙ ЖЕ Search-папки.
// Никаких других директорий.
//

app.use(
    express.static(
        ROOT
    )
);

// ============================================================
// STATUS
// ============================================================

app.get(
    "/api/status",
    (req, res) => {

        res.json({

            ok: true,

            server:
                "Search Server",

            html:
                HTML_FILE,

            port:
                PORT,

            sources: {

                google:
                    Boolean(
                        GOOGLE_API_KEY &&
                        GOOGLE_CX
                    ),

                yandex:
                    Boolean(
                        YANDEX_API_KEY &&
                        YANDEX_FOLDER_ID
                    ),

                duckduckgo:
                    true
            }
        });
    }
);

// ============================================================
// REGISTER
// ============================================================

app.post(
    "/api/register",
    (req, res) => {

        try {

            const {
                firstName,
                lastName,
                email,
                password
            } = req.body;

            if (
                !firstName ||
                !lastName ||
                !email ||
                !password
            ) {

                return res
                    .status(400)
                    .json({

                        ok: false,

                        error:
                            "Заполните все поля."
                    });
            }

            if (
                !/^[^\s@]+@[^\s@]+\.[^\s@]+$/
                    .test(email)
            ) {

                return res
                    .status(400)
                    .json({

                        ok: false,

                        error:
                            "Введите правильный email."
                    });
            }

            if (
                password.length < 6
            ) {

                return res
                    .status(400)
                    .json({

                        ok: false,

                        error:
                            "Пароль должен содержать минимум 6 символов."
                    });
            }

            const users =
                loadUsers();

            const exists =
                users.some(
                    user =>
                        String(
                            user.email
                        ).toLowerCase() ===
                        String(
                            email
                        ).toLowerCase()
                );

            if (exists) {

                return res
                    .status(409)
                    .json({

                        ok: false,

                        error:
                            "Пользователь с таким email уже существует."
                    });
            }

            const user = {

                id:
                    Date.now().toString(),

                firstName:
                    String(
                        firstName
                    ).trim(),

                lastName:
                    String(
                        lastName
                    ).trim(),

                email:
                    String(
                        email
                    ).trim(),

                password:
                    String(
                        password
                    ),

                createdAt:
                    new Date()
                        .toISOString()
            };

            users.push(user);

            saveUsers(users);

            res.json({

                ok: true,

                user: {

                    id:
                        user.id,

                    firstName:
                        user.firstName,

                    lastName:
                        user.lastName,

                    email:
                        user.email
                }
            });

        } catch (error) {

            console.error(
                "REGISTER ERROR:",
                error
            );

            res
                .status(500)
                .json({

                    ok: false,

                    error:
                        "Ошибка сервера."
                });
        }
    }
);

// ============================================================
// LOGIN
// ============================================================

app.post(
    "/api/login",
    (req, res) => {

        try {

            const {
                email,
                password
            } = req.body;

            if (
                !email ||
                !password
            ) {

                return res
                    .status(400)
                    .json({

                        ok: false,

                        error:
                            "Введите email и пароль."
                    });
            }

            const users =
                loadUsers();

            const user =
                users.find(
                    item =>
                        String(
                            item.email
                        ).toLowerCase() ===
                        String(
                            email
                        ).toLowerCase() &&

                        String(
                            item.password
                        ) ===
                        String(
                            password
                        )
                );

            if (!user) {

                return res
                    .status(401)
                    .json({

                        ok: false,

                        error:
                            "Неверный email или пароль."
                    });
            }

            res.json({

                ok: true,

                user: {

                    id:
                        user.id,

                    firstName:
                        user.firstName,

                    lastName:
                        user.lastName,

                    email:
                        user.email
                }
            });

        } catch (error) {

            console.error(
                "LOGIN ERROR:",
                error
            );

            res
                .status(500)
                .json({

                    ok: false,

                    error:
                        "Ошибка сервера."
                });
        }
    }
);

// ============================================================
// CLEAN TEXT
// ============================================================

function cleanText(value) {

    if (!value) {
        return "";
    }

    return String(value)
        .replace(
            /<[^>]*>/g,
            ""
        )
        .replace(
            /\s+/g,
            " "
        )
        .trim();
}

// ============================================================
// GOOGLE
// ============================================================

async function searchGoogle(
    query,
    safeSearch
) {

    if (
        !GOOGLE_API_KEY ||
        !GOOGLE_CX
    ) {

        return {

            source:
                "Google",

            enabled:
                false,

            results: [],

            error:
                "Google API не настроен."
        };
    }

    const params =
        new URLSearchParams();

    params.set(
        "key",
        GOOGLE_API_KEY
    );

    params.set(
        "cx",
        GOOGLE_CX
    );

    params.set(
        "q",
        query
    );

    params.set(
        "num",
        "10"
    );

    if (safeSearch) {

        params.set(
            "safe",
            "active"
        );
    }

    const response =
        await fetch(
            "https://www.googleapis.com/customsearch/v1?" +
            params.toString()
        );

    const data =
        await response.json();

    if (!response.ok) {

        throw new Error(
            data?.error?.message ||
            `Google HTTP ${response.status}`
        );
    }

    const results =
        Array.isArray(
            data.items
        )
            ? data.items.map(
                item => ({

                    title:
                        cleanText(
                            item.title
                        ),

                    url:
                        item.link,

                    snippet:
                        cleanText(
                            item.snippet
                        ),

                    displayUrl:
                        item.displayLink ||
                        item.link,

                    source:
                        "Google"
                })
            )
            : [];

    return {

        source:
            "Google",

        enabled:
            true,

        results,

        error:
            null
    };
}

// ============================================================
// DUCKDUCKGO
// ============================================================

async function searchDuckDuckGo(
    query
) {

    const params =
        new URLSearchParams();

    params.set(
        "q",
        query
    );

    params.set(
        "format",
        "json"
    );

    params.set(
        "no_html",
        "1"
    );

    params.set(
        "skip_disambig",
        "1"
    );

    params.set(
        "no_redirect",
        "1"
    );

    const response =
        await fetch(
            "https://api.duckduckgo.com/?" +
            params.toString()
        );

    if (!response.ok) {

        throw new Error(
            `DuckDuckGo HTTP ${response.status}`
        );
    }

    const data =
        await response.json();

    const results = [];

    if (
        data.AbstractURL &&
        data.AbstractText
    ) {

        results.push({

            title:
                cleanText(
                    data.Heading ||
                    query
                ),

            url:
                data.AbstractURL,

            snippet:
                cleanText(
                    data.AbstractText
                ),

            displayUrl:
                data.AbstractURL,

            source:
                "DuckDuckGo"
        });
    }

    function parseTopics(
        topics
    ) {

        if (
            !Array.isArray(
                topics
            )
        ) {
            return;
        }

        for (
            const item
            of topics
        ) {

            if (
                item.Topics
            ) {

                parseTopics(
                    item.Topics
                );

                continue;
            }

            if (
                item.FirstURL &&
                item.Text
            ) {

                results.push({

                    title:
                        cleanText(
                            item.Text
                        ),

                    url:
                        item.FirstURL,

                    snippet:
                        cleanText(
                            item.Text
                        ),

                    displayUrl:
                        item.FirstURL,

                    source:
                        "DuckDuckGo"
                });
            }
        }
    }

    parseTopics(
        data.RelatedTopics
    );

    return {

        source:
            "DuckDuckGo",

        enabled:
            true,

        results:
            results.slice(
                0,
                10
            ),

        error:
            null
    };
}

// ============================================================
// YANDEX
// ============================================================

async function searchYandex(
    query,
    safeSearch
) {

    if (
        !YANDEX_API_KEY ||
        !YANDEX_FOLDER_ID
    ) {

        return {

            source:
                "Yandex",

            enabled:
                false,

            results: [],

            error:
                "Yandex API не настроен."
        };
    }

    const response =
        await fetch(
            "https://searchapi.api.cloud.yandex.net/v2/web/search",
            {

                method:
                    "POST",

                headers: {

                    "Content-Type":
                        "application/json",

                    "Authorization":
                        `Api-Key ${YANDEX_API_KEY}`
                },

                body:
                    JSON.stringify({

                        query: {

                            searchQuery:
                                query
                        },

                        sortSpec: {

                            sortMode:
                                "SORT_MODE_BY_RELEVANCE"
                        },

                        groupSpec: {

                            groupingMethod:
                                "GROUPING_METHOD_HOST",

                            groupsOnPage:
                                10,

                            docsInGroup:
                                1
                        },

                        maxPassages:
                            3
                    })
            }
        );

    const data =
        await response.json();

    if (!response.ok) {

        throw new Error(
            data?.message ||
            `Yandex HTTP ${response.status}`
        );
    }

    const results = [];

    const groups =
        data?.results
            ?.searchResult
            ?.groups || [];

    for (
        const group
        of groups
    ) {

        const documents =
            group.documents ||
            [];

        for (
            const document
            of documents
        ) {

            const doc =
                document.document ||
                document;

            const url =
                doc.url ||
                "";

            const title =
                doc.title ||
                "";

            const snippet =
                doc.snippet ||
                "";

            if (
                url &&
                title
            ) {

                results.push({

                    title:
                        cleanText(
                            title
                        ),

                    url,

                    snippet:
                        cleanText(
                            snippet
                        ),

                    displayUrl:
                        url,

                    source:
                        "Yandex"
                });
            }
        }
    }

    return {

        source:
            "Yandex",

        enabled:
            true,

        results:
            results.slice(
                0,
                10
            ),

        error:
            null
    };
}

// ============================================================
// SEARCH
// ============================================================

app.get(
    "/api/search",
    async (
        req,
        res
    ) => {

        const query =
            String(
                req.query.q ||
                ""
            ).trim();

        const safeSearch =
            String(
                req.query.safe ||
                "1"
            ) !== "0";

        if (!query) {

            return res
                .status(400)
                .json({

                    ok: false,

                    error:
                        "Введите поисковый запрос."
                });
        }

        console.log(
            `Поиск: ${query}`
        );

        const searches =
            await Promise.allSettled([

                searchGoogle(
                    query,
                    safeSearch
                ),

                searchYandex(
                    query,
                    safeSearch
                ),

                searchDuckDuckGo(
                    query
                )
            ]);

        const allResults = [];

        const sources = [];

        const errors = [];

        for (
            const result
            of searches
        ) {

            if (
                result.status ===
                "fulfilled"
            ) {

                const data =
                    result.value;

                sources.push({

                    source:
                        data.source,

                    enabled:
                        data.enabled,

                    count:
                        data.results.length
                });

                if (
                    data.error
                ) {

                    errors.push({

                        source:
                            data.source,

                        error:
                            data.error
                    });
                }

                allResults.push(
                    ...data.results
                );

            } else {

                errors.push({

                    source:
                        "Unknown",

                    error:
                        result.reason?.message ||
                        "Ошибка"
                });
            }
        }

        // ====================================================
        // REMOVE DUPLICATES
        // ====================================================

        const seen =
            new Set();

        const unique = [];

        for (
            const item
            of allResults
        ) {

            if (!item.url) {
                continue;
            }

            let normalized;

            try {

                normalized =
                    new URL(
                        item.url
                    )
                        .toString()
                        .replace(
                            /\/$/,
                            ""
                        );

            } catch {

                normalized =
                    item.url;
            }

            if (
                seen.has(
                    normalized
                )
            ) {
                continue;
            }

            seen.add(
                normalized
            );

            unique.push(
                item
            );
        }

        res.json({

            ok: true,

            query,

            safeSearch,

            results:
                unique.slice(
                    0,
                    30
                ),

            total:
                unique.length,

            sources,

            errors
        });
    }
);

// ============================================================
// 404
// ============================================================

app.use(
    (req, res) => {

        res.status(404).send(`
            <!DOCTYPE html>
            <html lang="ru">
            <head>
                <meta charset="UTF-8">
                <title>404</title>
            </head>
            <body>
                <h1>404</h1>
                <p>Страница не найдена.</p>
                <a href="/">
                    Вернуться в Search
                </a>
            </body>
            </html>
        `);
    }
);

// ============================================================
// ERROR
// ============================================================

app.use(
    (
        error,
        req,
        res,
        next
    ) => {

        console.error(
            "SERVER ERROR:",
            error
        );

        if (
            res.headersSent
        ) {

            return next(
                error
            );
        }

        res
            .status(500)
            .json({

                ok: false,

                error:
                    error.message ||
                    "Ошибка сервера."
            });
    }
);

// ============================================================
// START
// ============================================================

app.listen(
    PORT,
    HOST,
    () => {

        console.log("");
        console.log(
            "========================================"
        );
        console.log(
            "        SEARCH SERVER ЗАПУЩЕН"
        );
        console.log(
            "========================================"
        );
        console.log("");

        console.log(
            "Папка Search:"
        );

        console.log(
            ROOT
        );

        console.log("");

        console.log(
            "HTML:"
        );

        console.log(
            HTML_FILE
        );

        console.log("");

        console.log(
            `Локально: http://localhost:${PORT}`
        );

        console.log("");

        console.log(
            "Поисковые источники:"
        );

        console.log(
            `Google: ${
                GOOGLE_API_KEY &&
                GOOGLE_CX
                    ? "ON"
                    : "OFF"
            }`
        );

        console.log(
            `Yandex: ${
                YANDEX_API_KEY &&
                YANDEX_FOLDER_ID
                    ? "ON"
                    : "OFF"
            }`
        );

        console.log(
            "DuckDuckGo: ON"
        );

        console.log("");

        console.log(
            "========================================"
        );

        console.log("");
    }
);