========================================================================
РУССКАЯ ИНСТРУКЦИЯ / RUSSIAN GUIDE
========================================================================

1. Установите Node.js на компьютер.
   Node.js должен быть установлен до запуска Search.

2. Вернитесь в папку "Search", где находятся:
   search.html
   server.js
   package.json

3. Кликните по адресной строке сверху
   (полоска рядом с кнопками "Назад" и "Обновить").

4. Удалите весь текст из адресной строки, напишите:
   cmd
   и нажмите Enter.

5. В открывшемся окне командной строки введите:
   node server.js
   и нажмите Enter.

6. После запуска сервера появится адрес:
   http://localhost:3000

7. Откройте этот адрес в браузере.
   Откроется поисковая система Search!

8. Чтобы остановить сервер, вернитесь в окно CMD
   и нажмите Ctrl+C.


========================================================================
ENGLISH INSTRUCTION / ENGLISH GUIDE
========================================================================

1. Install Node.js on your computer.
   Node.js must be installed before starting Search.

2. Return to the "Search" folder containing:
   search.html
   server.js
   package.json

3. Click the address bar at the top
   (the bar next to the Back and Refresh buttons).

4. Clear all the text in the address bar, type:
   cmd
   and press Enter.

5. In the Command Prompt window, type:
   node server.js
   and press Enter.

6. After the server starts, the following address will appear:
   http://localhost:3000

7. Open this address in your browser.
   The Search search engine will open!

8. To stop the server, return to the CMD window
   and press Ctrl+C.


========================================================================
SEARCH ENGINE
========================================================================

Search Engine: Search
Search Provider: DuckDuckGo
Backend: Node.js
Default Port: 3000
Local Address: http://localhost:3000

========================================================================