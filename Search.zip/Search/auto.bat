@echo off
echo Запуск поисковой системы Search...
echo Откройте в браузере: http://localhost:3000
echo.
node server.js
pause
